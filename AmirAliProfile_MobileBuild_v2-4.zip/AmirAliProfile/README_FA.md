# AmirAli Profile — نسخه 1.0

اپلیکیشن معرفی شخصی اندروید با Kotlin و Jetpack Compose.

## اجرا
1. فایل ZIP را استخراج کنید.
2. پوشه `AmirAliProfile` را در Android Studio باز کنید.
3. منتظر بمانید Gradle Sync کامل شود.
4. یک شبیه‌ساز یا گوشی اندرویدی متصل کنید و Run را بزنید.
5. برای ساخت APK از مسیر Build > Build APK(s) استفاده کنید.

## مشخصات
- حداقل اندروید: Android 7.0 (API 24)
- زبان: Kotlin
- رابط کاربری: Jetpack Compose + Material 3
- شناسه برنامه: `com.amirali.profile`

## شخصی‌سازی
اطلاعات معرفی، مهارت‌ها و پروژه‌ها در فایل `MainActivity.kt` قرار دارند.
برای تغییر نام یا متن‌ها، همان فایل را ویرایش کنید.

## فونت فارسی
نسخه اولیه از فونت پیش‌فرض سیستم استفاده می‌کند تا بدون فایل جانبی اجرا شود.
برای افزودن Vazirmatn:
1. فایل فونت Vazirmatn با پسوند `.ttf` را در `app/src/main/res/font/` قرار دهید (نام فایل با حروف کوچک، مانند `vazirmatn_regular.ttf`).
2. در Compose یک `FontFamily` با `Font(R.font.vazirmatn_regular)` بسازید و به `MaterialTheme` یا Textها بدهید.

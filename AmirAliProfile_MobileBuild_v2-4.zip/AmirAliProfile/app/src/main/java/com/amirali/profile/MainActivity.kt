package com.amirali.profile

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Ink = Color(0xFF080D18)
private val Panel = Color(0xFF111B2D)
private val Blue = Color(0xFF3987FF)
private val Cyan = Color(0xFF42D7FF)
private val Muted = Color(0xFF9AA9C0)
private val White = Color(0xFFF4F7FC)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ProfileApp() }
    }
}

private enum class Page(val title: String, val icon: ImageVector) {
    Home("خانه", Icons.Default.Home),
    About("درباره من", Icons.Default.Person),
    Skills("مهارت‌ها", Icons.Default.Code),
    Projects("پروژه‌ها", Icons.Default.Work),
    Goals("اهداف", Icons.Default.Flag)
}

@Composable
private fun ProfileApp() {
    var page by remember { mutableStateOf(Page.Home) }
    var darkMode by remember { mutableStateOf(true) }
    val background = if (darkMode) Ink else Color(0xFFF2F6FC)
    val surface = if (darkMode) Panel else Color.White
    val text = if (darkMode) White else Color(0xFF142033)
    val muted = if (darkMode) Muted else Color(0xFF65748B)

    MaterialTheme(
        colorScheme = if (darkMode) darkColorScheme(
            primary = Blue, secondary = Cyan, background = Ink, surface = Panel,
            onBackground = White, onSurface = White
        ) else lightColorScheme(
            primary = Blue, secondary = Cyan, background = Color(0xFFF2F6FC),
            surface = Color.White, onBackground = Color(0xFF142033),
            onSurface = Color(0xFF142033)
        )
    ) {
        Scaffold(
            containerColor = background,
            bottomBar = {
                NavigationBar(
                    containerColor = surface,
                    contentColor = text,
                    tonalElevation = 0.dp
                ) {
                    Page.entries.forEach { item ->
                        NavigationBarItem(
                            selected = page == item,
                            onClick = { page = item },
                            icon = { Icon(item.icon, contentDescription = item.title) },
                            label = { Text(item.title, fontSize = 10.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Blue,
                                selectedTextColor = Blue,
                                indicatorColor = Blue.copy(alpha = .13f),
                                unselectedIconColor = muted,
                                unselectedTextColor = muted
                            )
                        )
                    }
                }
            }
        ) { padding ->
            AnimatedContent(
                targetState = page,
                transitionSpec = { fadeIn() togetherWith fadeOut() },
                label = "page-transition",
                modifier = Modifier.padding(padding)
            ) { current ->
                when (current) {
                    Page.Home -> HomeScreen(text, muted, surface, onNavigate = { page = it })
                    Page.About -> AboutScreen(text, muted, surface)
                    Page.Skills -> SkillsScreen(text, muted, surface)
                    Page.Projects -> ProjectsScreen(text, muted, surface)
                    Page.Goals -> GoalsScreen(text, muted, surface, darkMode) { darkMode = !darkMode }
                }
            }
        }
    }
}

@Composable
private fun PageHeader(title: String, subtitle: String, text: Color, muted: Color) {
    Column(modifier = Modifier.fillMaxWidth().padding(bottom = 18.dp)) {
        Text(title, color = text, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(5.dp))
        Text(subtitle, color = muted, fontSize = 13.sp)
    }
}

@Composable
private fun HomeScreen(
    text: Color, muted: Color, surface: Color, onNavigate: (Page) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(horizontal = 20.dp),
        contentPadding = PaddingValues(top = 24.dp, bottom = 28.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("AMIRALI  /  VC", color = Cyan, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                    Text("پروفایل شخصی", color = muted, fontSize = 12.sp)
                }
                Box(
                    Modifier.size(42.dp).clip(CircleShape)
                        .background(Brush.linearGradient(listOf(Blue, Cyan))),
                    contentAlignment = Alignment.Center
                ) { Text("A", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Black) }
            }
            Spacer(Modifier.height(28.dp))
            Box(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp))
                    .background(Brush.linearGradient(listOf(Color(0xFF173D78), Color(0xFF101A2D), Color(0xFF132C43))))
                    .padding(22.dp)
            ) {
                Column {
                    Text("سلام، من", color = Color(0xFFB9D8FF), fontSize = 14.sp)
                    Text("امیرعلی موسیوند", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.ExtraBold)
                    Spacer(Modifier.height(8.dp))
                    Text("Programmer • Technology Enthusiast", color = Color(0xFFD2E5FF), fontSize = 12.sp)
                    Spacer(Modifier.height(18.dp))
                    Text(
                        "علاقه‌مند به ساختن، یادگیری و تبدیل ایده‌ها به پروژه‌های واقعی.",
                        color = Color.White.copy(alpha = .88f), fontSize = 14.sp, lineHeight = 25.sp
                    )
                    Spacer(Modifier.height(20.dp))
                    Surface(color = Blue, shape = RoundedCornerShape(50)) {
                        Text("Explore my world  ↗", color = Color.White, modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp), fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
            Spacer(Modifier.height(25.dp))
            Text("مسیر من", color = text, fontSize = 19.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(12.dp))
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MiniStat("01", "ایده‌پردازی", surface, text, muted, Modifier.weight(1f))
                MiniStat("02", "یادگیری", surface, text, muted, Modifier.weight(1f))
                MiniStat("03", "ساختن", surface, text, muted, Modifier.weight(1f))
            }
            Spacer(Modifier.height(24.dp))
            Text("بخش‌های پروفایل", color = text, fontSize = 19.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(12.dp))
        }
        items(listOf(
            Triple("درباره من", "با علایق و مسیر من آشنا شو", Page.About),
            Triple("مهارت‌ها", "زمینه‌هایی که دنبال می‌کنم", Page.Skills),
            Triple("پروژه‌ها", "ایده‌هایی که به محصول تبدیل می‌شوند", Page.Projects),
            Triple("اهداف", "چشم‌انداز و برنامه‌های آینده", Page.Goals)
        )) { entry ->
            Row(
                Modifier.fillMaxWidth().padding(bottom = 10.dp).clip(RoundedCornerShape(18.dp))
                    .background(surface).clickable { onNavigate(entry.third) }.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text(entry.first, color = text, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Text(entry.second, color = muted, fontSize = 12.sp)
                }
                Icon(Icons.Default.ArrowBack, contentDescription = null, tint = Blue)
            }
        }
        item {
            Spacer(Modifier.height(10.dp))
            Text("«هرآنچه نمی‌شود، ما می‌توانیم.»", color = Cyan, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
            Spacer(Modifier.height(10.dp))
            Text("© AmirAli VC", color = muted, fontSize = 11.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
        }
    }
}

@Composable
private fun MiniStat(number: String, label: String, surface: Color, text: Color, muted: Color, modifier: Modifier) {
    Column(modifier.clip(RoundedCornerShape(16.dp)).background(surface).padding(13.dp)) {
        Text(number, color = Blue, fontSize = 19.sp, fontWeight = FontWeight.ExtraBold)
        Text(label, color = muted, fontSize = 11.sp)
    }
}

@Composable
private fun ContentPage(title: String, subtitle: String, text: Color, muted: Color, surface: Color, content: @Composable ColumnScope.() -> Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 20.dp), contentPadding = PaddingValues(top = 26.dp, bottom = 30.dp)) {
        item {
            PageHeader(title, subtitle, text, muted)
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(surface).padding(20.dp),
                content = content
            )
        }
    }
}

@Composable
private fun InfoLine(label: String, value: String, text: Color, muted: Color) {
    Column(Modifier.fillMaxWidth().padding(vertical = 9.dp)) {
        Text(label, color = Blue, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        Text(value, color = text, fontSize = 14.sp, lineHeight = 24.sp)
    }
}

@Composable
private fun AboutScreen(text: Color, muted: Color, surface: Color) {
    ContentPage("درباره من", "کمی بیشتر با من آشنا شو", text, muted, surface) {
        Text("AmirAli Mosivand", color = text, fontSize = 21.sp, fontWeight = FontWeight.Bold)
        Text("AmirAli VC", color = Cyan, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(12.dp))
        Text(
            "من امیرعلی هستم؛ علاقه‌مند به دنیای برنامه‌نویسی، هوش مصنوعی و فناوری. دوست دارم با کنجکاوی، تمرین و ساخت پروژه‌های واقعی مهارت‌هایم را توسعه بدهم.",
            color = text, fontSize = 14.sp, lineHeight = 27.sp
        )
        HorizontalDivider(Modifier.padding(vertical = 12.dp), color = muted.copy(alpha = .25f))
        InfoLine("حوزه فعالیت", "برنامه‌نویسی و فناوری", text, muted)
        InfoLine("علایق", "هوش مصنوعی، علوم، فضا و الکترونیک", text, muted)
        InfoLine("نگرش", "یادگیری مداوم و ساختن چیزهای مفید", text, muted)
    }
}

@Composable
private fun SkillsScreen(text: Color, muted: Color, surface: Color) {
    val skills = listOf(
        "برنامه‌نویسی" to "در حال یادگیری و توسعه مهارت",
        "هوش مصنوعی" to "آشنایی و تجربه ساخت ابزارهای AI",
        "طراحی رابط کاربری" to "علاقه‌مند به طراحی مدرن و مینیمال",
        "وب و فناوری" to "ساخت و مدیریت پروژه‌های دیجیتال",
        "حل مسئله" to "یادگیری از طریق تمرین و تجربه"
    )
    ContentPage("مهارت‌ها", "چیزهایی که یاد می‌گیرم و توسعه می‌دهم", text, muted, surface) {
        skills.forEachIndexed { index, item ->
            Row(Modifier.fillMaxWidth().padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(38.dp).clip(RoundedCornerShape(12.dp)).background(Blue.copy(alpha = .15f)), contentAlignment = Alignment.Center) {
                    Text("0${index + 1}", color = Cyan, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.width(12.dp))
                Column {
                    Text(item.first, color = text, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text(item.second, color = muted, fontSize = 11.sp)
                }
            }
            if (index != skills.lastIndex) HorizontalDivider(color = muted.copy(alpha = .18f))
        }
        Spacer(Modifier.height(10.dp))
        Text("این بخش با پیشرفت مهارت‌ها قابل به‌روزرسانی است.", color = muted, fontSize = 11.sp)
    }
}

@Composable
private fun ProjectsScreen(text: Color, muted: Color, surface: Color) {
    val projects = listOf(
        Triple("Shad AI", "دستیار هوشمند فارسی با قابلیت گفتگو و ابزارهای متنوع", "AI / Python"),
        Triple("AmirAli Store", "ایده فروشگاه دیجیتال با تجربه کاربری مدرن", "Web / E-commerce"),
        Triple("AmirAli Bot", "ربات پیام‌رسان برای خودکارسازی برخی کارها", "Automation")
    )
    ContentPage("پروژه‌ها", "ایده‌ها و تجربه‌های من در دنیای ساختن", text, muted, surface) {
        projects.forEachIndexed { index, project ->
            Column(Modifier.fillMaxWidth().padding(vertical = 12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("0${index + 1}", color = Blue, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
                    Spacer(Modifier.width(12.dp))
                    Text(project.first, color = text, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
                Text(project.second, color = muted, fontSize = 13.sp, lineHeight = 23.sp, modifier = Modifier.padding(top = 7.dp))
                Text(project.third, color = Cyan, fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp))
            }
            if (index != projects.lastIndex) HorizontalDivider(color = muted.copy(alpha = .18f))
        }
        Text("نمونه‌های این صفحه قابل ویرایش و تکمیل هستند.", color = muted, fontSize = 11.sp)
    }
}

@Composable
private fun GoalsScreen(text: Color, muted: Color, surface: Color, darkMode: Boolean, onToggleTheme: () -> Unit) {
    ContentPage("اهداف و تنظیمات", "مسیر پیش رو و شخصی‌سازی برنامه", text, muted, surface) {
        Text("چشم‌انداز من", color = text, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text("تبدیل‌شدن به فردی توانمند در فناوری؛ کسی که ایده‌های خلاقانه را به ابزارها و محصولات مفید تبدیل می‌کند.", color = text, fontSize = 14.sp, lineHeight = 27.sp)
        Spacer(Modifier.height(16.dp))
        listOf("یادگیری عمیق برنامه‌نویسی", "ساخت پروژه‌های کاربردی", "شناخت بهتر هوش مصنوعی و علوم", "به‌اشتراک‌گذاری تجربه‌ها").forEachIndexed { i, goal ->
            Row(Modifier.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Cyan, modifier = Modifier.size(19.dp))
                Spacer(Modifier.width(10.dp))
                Text(goal, color = text, fontSize = 13.sp)
            }
        }
        HorizontalDivider(Modifier.padding(vertical = 14.dp), color = muted.copy(alpha = .2f))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("حالت تیره", color = text, fontWeight = FontWeight.Bold)
                Text("تغییر ظاهر برنامه", color = muted, fontSize = 11.sp)
            }
            Switch(checked = darkMode, onCheckedChange = { onToggleTheme() })
        }
        Spacer(Modifier.height(16.dp))
        Text("نسخه 1.0.0  •  AmirAli VC", color = muted, fontSize = 11.sp)
    }
}
